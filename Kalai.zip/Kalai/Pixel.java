package com.sample.test;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.time.Duration;
import java.time.Instant;

import javax.imageio.ImageIO;

public class Pixel {
   BufferedImage image;
   int width;
   int height;
   
   public Pixel() {
      try {
         File input = new File("E:\\Desktop\\Kalai\\test1.png");
         image = ImageIO.read(input);
         width = image.getWidth();
         height = image.getHeight();
         Instant start = Instant.now();
         boolean isValid = false;
         for(int i=0; i<height; i++) {
            for(int j=0; j<width; j++) {
               Color c = new Color(image.getRGB(j, i));
               //System.out.println("S.No: " + c.getRGB() + " Red: " + c.getRed() +"  Green: " + c.getGreen() + " Blue: " + c.getBlue());
               System.out.println((c.getRGB() == -65536 || c.getRGB() == -1) && (c.getRed() == 0 || c.getRed() == 255) && (c.getGreen() == 0 || c.getGreen() == 255) && (c.getBlue() == 0 || c.getBlue() == 255));
               if (!(c.getRGB() == -65536 || c.getRGB() == -1) && (c.getRed() == 0 || c.getRed() == 255) && (c.getGreen() == 0 || c.getGreen() == 255) && (c.getBlue() == 0 || c.getBlue() == 255)) {
            	   isValid = false;
            	   break;
               }
            }
         }
         //System.out.println("Is Valid " +  isValid);
         Instant end = Instant.now();
         Duration timeElapsed = Duration.between(start, end);
         System.out.println("Time taken: "+ timeElapsed.getSeconds() +" Seconds");
      } catch (Exception e) {
    	  e.printStackTrace();
      }
   }
   
   static public void main(String args[]) throws Exception {
      Pixel obj = new Pixel();
   }
}